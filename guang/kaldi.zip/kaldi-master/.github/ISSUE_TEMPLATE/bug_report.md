---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

<!--
    WARNING: THE KALDI ISSUE TRACKER IS **ONLY** USED FOR KALDI DEVELOPMENT!

    If you have a question about using Kaldi, please use the kald-help discussion group:

    https://groups.google.com/forum/#!forum/kaldi-help

    Instructions for joining are available at: http://kaldi-asr.org/forums.html
-->
